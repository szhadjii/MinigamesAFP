using System.Windows;
using System.Windows.Controls;

namespace HangmanPro
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();

            // Biztonságos fókusz: csak betöltés után állítjuk be
            Loaded += (_, __) => PlayerNameBox.Focus();
        }

        private void StartGame_Click(object sender, RoutedEventArgs e)
        {
            // 1) Játékosnév – üres/whitespace esetén "Vendég"
            string playerName = PlayerNameBox.Text?.Trim() ?? string.Empty;
            if (string.IsNullOrWhiteSpace(playerName))
            {
                playerName = "Vendég";
            }

            // 2) Nehézség – alapértelmezett: közepes (1)
            int difficultyIndex = DifficultyComboBox.SelectedIndex >= 0
                ? DifficultyComboBox.SelectedIndex
                : 1;

            // 3) Időtartam – alapértelmezett: 5 perc (300 mp)
            int[] durations = { 180, 300, 600, 0 };
            int durationSeconds = DurationComboBox.SelectedIndex >= 0
                ? durations[DurationComboBox.SelectedIndex]
                : 300;

            // 4) Kategória – alapértelmezett: "Általános", ha nincs kiválasztva
            string selectedCategory = (CategoryComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString()
                                      ?? "Általános";

            // 5) Főablak indítása
            var main = new MainWindow(playerName, difficultyIndex, durationSeconds, selectedCategory);
            main.Show();
            Close();
        }
    }
}